"""
**Utility functions** for LangChain.
"""
